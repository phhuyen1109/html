// script.js
// Adds mouse and keyboard focus/blur interactions and injects tabindex on load.

(function(){
  // Query all images (initially they do NOT have tabindex)
  const images = document.querySelectorAll('.gallery-item');

  // Handler used for both mouseover and focus
  function addHighlight(event) {
    // Use currentTarget to avoid issues when event bubbles
    const img = event.currentTarget;
    img.classList.add('highlight');

    // show the figcaption if present
    const caption = img.parentElement.querySelector('figcaption');
    if (caption) caption.classList.add('visible');
  }

  // Handler used for both mouseleave and blur
  function removeHighlight(event) {
    const img = event.currentTarget;
    img.classList.remove('highlight');

    const caption = img.parentElement.querySelector('figcaption');
    if (caption) caption.classList.remove('visible');
  }

  // Optional: allow Enter/Space to "activate" an image (demonstration only)
  function handleKeyActivate(event) {
    // 13 = Enter, 32 = Space
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      // simple feedback: briefly pulse the image
      const img = event.currentTarget;
      img.classList.add('highlight');
      setTimeout(()=> img.classList.remove('highlight'), 250);
      // In real apps you might open a lightbox or navigate
      console.log('Image activated by keyboard:', img.alt);
    }
  }

  // Attach mouse and keyboard listeners using the same pattern
  images.forEach(img => {
    img.addEventListener('mouseover', addHighlight, {passive: true});
    img.addEventListener('mouseleave', removeHighlight);
    img.addEventListener('focus', addHighlight);
    img.addEventListener('blur', removeHighlight);
    img.addEventListener('keydown', handleKeyActivate);
  });

  // onload listener that will add tabindex attributes so images are keyboard-focusable
  window.addEventListener('load', addTabIndexToImages);

  // New function to add tabindex (this is the function the assignment asked for)
  function addTabIndexToImages(){
    console.log('addTabIndexToImages triggered — adding tabindex to gallery images');

    // re-query in case DOM changed before load
    const imgs = document.querySelectorAll('.gallery-item');
    for (let i = 0; i < imgs.length; i++) {
      // Add tabindex so the image can receive keyboard focus
      imgs[i].setAttribute('tabindex', '0');

      // For accessibility, ensure each image has an accessible name (alt is used here)
      // Optionally add role if you intend them to be interactive (e.g., button)
      // imgs[i].setAttribute('role', 'img'); // role=image is redundant when using <img>

      // You can also add aria-describedby linking to caption if needed:
      // const caption = imgs[i].parentElement.querySelector('figcaption');
      // if (caption) {
      //   caption.id = caption.id || `cap-${i+1}`;
      //   imgs[i].setAttribute('aria-describedby', caption.id);
      // }
    }

    console.log(`Added tabindex to ${imgs.length} images.`);
  }

})();