// Hàm upDate được gọi khi hover vào ảnh (onmouseover="upDate(this)")
function upDate(previewPic) {
  // a) kiểm tra event đang trigger
  console.log('upDate triggered');

  // b) in thông tin của previewPic (alt và src)
  console.log('previewPic.alt =', previewPic.alt);
  console.log('previewPic.src =', previewPic.src);

  // c) thay đổi nội dung text của phần tử có id = "image"
  var imageDiv = document.getElementById('image');
  if (imageDiv) {
    imageDiv.innerHTML = previewPic.alt;
  } else {
    console.warn('Element with id "image" not found.');
  }

  // e) thay đổi background-image của phần tử có id = "image"
  // dùng previewPic.src làm url cho background
  if (imageDiv) {
    imageDiv.style.backgroundImage = "url('" + previewPic.src + "')";
  }

  // f) kiểm tra nếu không hoạt động thì dùng console.log để debug (đã có ở trên)
}

// Hàm undo được gọi khi rời ảnh (onmouseout="undo()")
function undo() {
  var imageDiv = document.getElementById('image');
  if (!imageDiv) {
    console.warn('Element with id "image" not found.');
    return;
  }

  // 4.a: cập nhật url background-image về giá trị ban đầu url('')
  imageDiv.style.backgroundImage = "url('')";

  // 4.b: cập nhật text về giá trị ban đầu
  imageDiv.innerHTML = 'Hover over an image below to display here.';
}